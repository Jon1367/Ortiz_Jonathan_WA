/*  jQuery*/
$(function(){


	$('#logo').hover(function(){

		$('#numbers').fadeIn();

	})

})